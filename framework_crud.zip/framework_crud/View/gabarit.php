<!doctype html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" href="Contenu/style.css" /> 
<title><?= $title ?></title>
    </head>
    <body>
        <div id="global">
            <header>
<h1 style="text-align: center; margin-top: 30px;
 font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Ubuntu, 'Open Sans', 'Helvetica Neue', sans-serif;
  " id="titreBlog">Formulaire des Etudiants</h1></a>
 </header>
            <div id="content">
                <?= $content ?>
            </div> 
            <!-- #contenu --> 
    </div>
</div> <!-- #global -->
    </body>
</html>