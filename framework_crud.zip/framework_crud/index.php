<?php
require 'Controller/Route.php'; 

$route = new Route();
$route->routeRequest();

?>
